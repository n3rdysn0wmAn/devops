<?php 
echo "hello";
phpinfo(); 

?>